﻿internal interface IMyEngineActions
{
    public bool Execute();
}
